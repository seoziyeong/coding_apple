import './App.css';
import { useState } from 'react'
import { Nav, Navbar, Container, Button } from 'react-bootstrap'
import { Routes, Route, useNavigate } from "react-router-dom";
import axios from 'axios'
import data from './data.js'
import Detail from './routes/Detail.js'

function App() {
  let [shoes, setShoes] = useState(data)
  const navigate = useNavigate();

  // ^ 메인 UI
  function Main({shoes}) {
    // 상품 더 보기 GET
    function getdata() {
      axios.get('https://codingapple1.github.io/shop/data2.json')
        .then((res) => { 
          let copy = [...shoes, ...res.data]
          setShoes(copy)
          console.log(copy)
        })
        .catch((err) => { console.log('실패함 ㅅㄱ')})
    }

    return (
      <>
        <div className="main-bg"></div>
        <div className="container">
          <div className="row">
            { shoes.map((shoes,i) => {
              return (
                <div
                  className="col-md-4"
                  onClick={() => navigate(`/detail/${+i}`)}
                >
                  <img src={`https://codingapple1.github.io/shop/shoes${i+1}.jpg`} width="80%" alt=""/>
                  <h4>{shoes.title}</h4>
                  <p>{shoes.price}</p>
                </div>
              )})
            }
          </div>
        </div>
        <Button variant="outline-secondary" onClick={getdata}>더 보기</Button>
      </>
    )
  }

  // ^ App
  return (
    <div className="App">
      <Navbar bg="dark" variant="dark">
        <Container>
          <Navbar.Brand href="#home">J-Market</Navbar.Brand>
          <Nav className="me-auto">
            <Nav.Link onClick={() => {navigate('/')}}>HOME</Nav.Link>
            <Nav.Link onClick={() => {navigate('/detail')}}>DETAIL</Nav.Link>
            <Nav.Link onClick={() => {navigate('/event')}}>EVENT</Nav.Link>
          </Nav>
        </Container>
      </Navbar>

      <Routes>
        <Route path="/" element={<Main shoes={shoes} />} />
        <Route path="*" element={<p>404</p>} />
        <Route path="/detail/:id" element={<Detail shoes={shoes}/>} />
      </Routes>

      
    </div>
  );
}






export default App;
